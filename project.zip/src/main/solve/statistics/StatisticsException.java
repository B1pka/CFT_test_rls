package statistics;

public class StatisticsException extends Exception {
    public StatisticsException(String message) {
        super(message);
    }
    public StatisticsException(String message, Throwable cause) {
        super(message, cause);
    }
}
