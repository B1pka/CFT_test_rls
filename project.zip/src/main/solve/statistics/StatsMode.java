package statistics;

public enum StatsMode {
    SHORT,
    FULL
}
