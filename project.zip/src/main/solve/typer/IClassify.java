package typer;

public interface IClassify {
    public DataType classify(String value);
}
