package typer;

public enum DataType {
    INT,
    FLOAT,
    STRING
}
