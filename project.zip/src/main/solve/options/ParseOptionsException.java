package options;

public class ParseOptionsException extends Exception {

    public ParseOptionsException(String message) {
        super(message);
    }
    public ParseOptionsException(String message, Throwable cause) {
        super(message, cause);
    }
}
