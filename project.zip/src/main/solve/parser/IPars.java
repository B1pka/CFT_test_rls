package parser;

import java.util.List;

public interface IPars {
    public void parser(List<String> inputFiles) throws ParseDataException;
}
